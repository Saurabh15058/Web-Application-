const mongoose = require("mongoose");
const Schema = mongoose.Schema;

const usersSchema = new Schema({
    user_email: String,
    user_email_en: String,
    user_name: String,
    user_password: String,
    user_mobile: String,
    user_type: Number,
    user_status: Number,
    user_create: Number,
    user_update: Number,
},{ versionKey: false });

module.exports = mongoose.model("tbl_users", usersSchema);