const mongoose = require("mongoose");
const Schema = mongoose.Schema;

const usersSchema = new Schema({
    device_name: String,
    device_uuid: String,
    user_email: String,
    device_status: Number,
    device_create: Number,
    device_update: Number,
},{ versionKey: false });

module.exports = mongoose.model("tbl_devices", usersSchema);