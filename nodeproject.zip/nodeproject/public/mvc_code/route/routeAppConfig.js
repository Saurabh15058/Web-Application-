const app = require('express').Router();
const jwtDecode = require('jwt-decode');
const jwt = require('jsonwebtoken');

module.exports = (function() {

	function ensureAuthorized(req, res, next)
	{		
		var token = req.headers['authorization'];
		if (!token) return res.status(401).send({ auth: false, message: 'No token provided.' });

		jwt.verify(token,process.env.jwtKey, function(err, decoded) {
			if (err) return res.status(500).send({ auth: false, message: 'Failed to authenticate token.' });
			req.user = decoded;
			next();
		});
	} 

	//Controller
	const usersCtrl = require("../controller/usersController");

	app.post("/login",usersCtrl.login);
	app.post("/register",usersCtrl.register);
	app.post("/register",usersCtrl.register);

	//Admin Dashboatd
	const adminDashboardCtrl = require("../controller/adminDashboardController");
	app.post("/getdashboardcount",ensureAuthorized,adminDashboardCtrl.getdashboardcount);

	//User Management
	const userManagementCtrl = require("../controller/userManagementController");
	app.post("/getallusers",ensureAuthorized,userManagementCtrl.getallusers);
	app.post("/adminedituser",ensureAuthorized,userManagementCtrl.adminedituser);
	app.post("/deleteUserAdmin",ensureAuthorized,userManagementCtrl.deleteUserAdmin);

	const deviceCtrl = require("../controller/deviceController");
	app.post("/adddevice",deviceCtrl.adddevice);
	app.post("/getalldevice",deviceCtrl.getalldevice);

    return app;
})();