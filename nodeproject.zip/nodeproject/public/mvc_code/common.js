module.exports = {
	getEpoch: function() {
		let d = new Date();
		let TiDt =  Math.round(d.getTime() / 1000);
		return TiDt;
	}
};