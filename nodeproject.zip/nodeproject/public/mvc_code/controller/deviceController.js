const tbl_devices = require("../model/tbl_devices");
const commonJS = require('../common.js');

const md5Enc = require('md5');
const jwt = require('jsonwebtoken');

exports.getalldevice  = async (req, res) => {

	tbl_devices.find({ }, (err, device) => {
		if(err){
			res.status(200).json({ status: 0,msg:"Get All Device Fail"});
		}
		else{
			res.status(200).json({ status: 1,msg:"Get All Device Success",device:device});
		}
	});	
}

exports.adddevice  = async (req, res) => {

	tbl_devices.find({ device_uuid:req.body.device_uuid }, (err, users) => {
		if(users.length == 0){
			//New User Register
			var newDevice = new tbl_devices({ 
					device_name: req.body.device_name,
					device_uuid: req.body.device_uuid,
					user_email: req.body.user_email,
					device_status: 1,
					device_create: commonJS.getEpoch(),
					device_update: commonJS.getEpoch()
			});
			newDevice.save((err, task) => { 
            	if (err) { console.log(err,'newUser'); } 
            	//User Success
				res.status(200).json({ status: 1,msg:"Device Added Success"});
            });
		}
		else{
			res.status(200).json({ status: 0,msg:"Device already exists!"});
		}
	});	
}