const tbl_users = require("../model/tbl_users");
const commonJS = require('../common.js');

const md5Enc = require('md5');
const jwt = require('jsonwebtoken');

exports.getdashboardcount  = async (req, res) => {
    console.log("getdashboardcount Called");
    //Count User App
	tbl_users.find({user_status:1,user_type:2}, (err, activateUser) => {
		if(err){
			res.status(200).json({ status: 0,msg:"Get Data Fail"});
		}
		else{
            tbl_users.find({user_status:0,user_type:2}, (err, deactiveUser) => {
                if(err){
                    res.status(200).json({ status: 0,msg:"Get Data Fail"});
                }
                else{
                    res.status(200).json({ status: 1,msg:"Get Data Success",activateUser:activateUser.length,deactiveUser:deactiveUser.length});
                }
              });
		}
  	});
}