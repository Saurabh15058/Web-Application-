const tbl_users = require("../model/tbl_users");
const commonJS = require('../common.js');

const md5Enc = require('md5');
const jwt = require('jsonwebtoken');

exports.login  = async (req, res) => {

	var user_email = req.body.user_email;
	var user_password = md5Enc(req.body.user_password);

    //Count User App
	tbl_users.find({user_email:user_email,user_password:user_password,user_status:1}, (err, users) => {
		if(err){
			res.status(200).json({ status: 0,msg:"Something Went Wrong"});
		}
		else if(users.length == 1){
			var user_data = { 
				user_name: users[0].user_name,
				user_email: users[0].user_email,
				user_mobile: users[0].user_mobile,
				user_type: users[0].user_type,
				user_status: users[0].user_status
			};
			var jwtKey = process.env.jwtKey;
			var JWTToken = jwt.sign(user_data, jwtKey, {
				algorithm: 'HS256',
				expiresIn: '2h'
			})

			res.status(200).json({ status: 1,msg:"Login Success",token:JWTToken,user_data:user_data});
		}
		else{
	    	res.status(200).json({ status: 0,msg:"Login Fail"});
		}
  	});
}


exports.register  = async (req, res) => {

	var user_email = req.body.user_email;
	var user_email_en = md5Enc(user_email);
	var user_name = req.body.user_name;
	var user_password = md5Enc(req.body.user_password);
	var user_mobile = req.body.user_mobile;
	var user_type = parseInt(2); //1-Admin 2-User
	var user_status = parseInt(0);


	tbl_users.find({ user_email:user_email }, (err, users) => {
		if(users.length == 0){
			//New User Register
			var newUser = new tbl_users({ 
						user_email: user_email, 
						user_email_en:user_email_en,
						user_name: user_name, 
						user_password: user_password, 
						user_mobile:user_mobile,
						user_type: user_type, 
						user_status: user_status,
						user_create: commonJS.getEpoch(),
						user_update: commonJS.getEpoch()
					});
            newUser.save((err, task) => { 
            	if (err) { console.log(err,'newUser'); } 
            	//User Success
				res.status(200).json({ status: 1,msg:"Thanks for signing up! Kindly check your email for the verification link"});
            });
		}
		else{
			res.status(200).json({ status: 0,msg:"An account with these credentials already exists!"});
		}
	});	
}
