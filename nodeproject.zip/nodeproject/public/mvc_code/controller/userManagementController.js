const tbl_users = require("../model/tbl_users");
const commonJS = require('../common.js');

const md5Enc = require('md5');
const jwt = require('jsonwebtoken');

exports.getallusers  = async (req, res) => {
    //Count User App
	tbl_users.find({user_status:1,user_type:2}, (err, activateUser) => {
		if(err){
			res.status(200).json({ status: 0,msg:"Get Data Fail"});
		}
		else{
            tbl_users.find({user_status:0,user_type:2}, (err, deactiveUser) => {
                if(err){
                    res.status(200).json({ status: 0,msg:"Get Data Fail"});
                }
                else{
                    res.status(200).json({ status: 1,msg:"Get Data Success",activateUser:activateUser,deactiveUser:deactiveUser});
                }
              });
		}
  	});
}

exports.adminedituser  = async (req, res) => {

    var user_email = req.body.user_email;
	var user_name = req.body.user_name;
	var user_password = req.body.user_password;
	var user_password_en = md5Enc(user_password);
	var user_mobile = req.body.user_mobile;

	if(req.body.pass_type == "noupdate"){
		var myquery = { user_email: user_email };
  		var newvalues = { $set: {user_name: user_name, user_mobile:user_mobile, user_update:commonJS.getEpoch() } };
	}
	else{
		var myquery = { user_email: user_email };
  		var newvalues = { $set: {user_name: user_name,user_password:user_password_en, user_mobile:user_mobile, user_update:commonJS.getEpoch() } };	
	}
              	
  	tbl_users.updateOne(myquery,newvalues,function(err, verifyUser) {
  		if(err){ 
  			res.status(200).json({ status: 0,msg:"Something Went Wrong!"});
  		}
  		else{
			res.status(200).json({ status: 1,msg:"User Records has been successfully updated!"});
  		}
  	});
}

exports.deleteUserAdmin  = async (req, res) => {
    
	let myquery = { user_email: req.body.user_email };
  	let newvalues = { $set: {user_status: 2, user_update:commonJS.getEpoch() } };
              	
  	tbl_users.updateOne(myquery,newvalues,function(err, verifyUser) {
  		if(err){ 
  			res.status(200).json({ status: 0,msg:"Something Went Wrong!"});
  		}
  		else{
			res.status(200).json({ status: 1,msg:"User has been successfully deleted!"});
  		}
      });
      
}